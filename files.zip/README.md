```markdown
# PSU Guide

โปรเจกต์เว็บไซต์สำหรับแนะนำข้อมูลต่าง ๆ ของ PSU (ต้นแบบ)

โครงสร้าง:
- index.html
- style.css
- images/    (วางรูปประกอบที่นี่)

การใช้งานเบื้องต้น:
1. สร้าง repo บน GitHub ชื่อ `psu-guide`
2. รันคำสั่งต่อไปนี้ (ปรับ `<USERNAME>` เป็นชื่อบัญชีของคุณ)
   ```bash
   git init
   git add .
   git commit -m "Initial commit: PSU Guide Website"
   git branch -M main
   git remote add origin https://github.com/<USERNAME>/psu-guide.git
   git push -u origin main
   ```
3. (ทางเลือก) ใช้ GitHub CLI เพื่อสร้างและ push อัตโนมัติ:
   ```bash
   gh repo create <USERNAME>/psu-guide --public --source=. --remote=origin --push
   ```

การ deploy เป็น GitHub Pages:
- เข้าไปที่ Settings > Pages หรือใช้คำสั่ง gh (extension) เพื่อเปิด Pages
```